# Web Admin Next

Scaffold reserve pour le backoffice Next.js (Lot 20).
Pour la version minimale fonctionnelle, une page d'administration baseline est servie par `services/api-gateway` sur `/admin`.
