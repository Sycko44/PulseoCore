# Mobile Flutter

Scaffold reserve pour le shell mobile baseline (Lot 19A).
Le noyau fonctionnel minimal est aujourd'hui porte par le service `api-gateway`.
