from __future__ import annotations

import os
import sys
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[2]
SERVICE_DIR = ROOT / "services" / "api-gateway"
DB_FILE = SERVICE_DIR / "data" / "test_pulseo.db"
if DB_FILE.exists():
    DB_FILE.unlink()

os.environ["DATABASE_URL"] = f"sqlite:///{DB_FILE}"
os.environ["JWT_SECRET"] = "test-secret-1234567890-1234567890"
os.environ["JWT_REFRESH_SECRET"] = "test-refresh-secret-1234567890-1234567890"
sys.path.insert(0, str(SERVICE_DIR))

from app.main import app  # noqa: E402
from app.db import init_db  # noqa: E402

init_db()
client = TestClient(app)


def auth_headers() -> dict[str, str]:
    reg = client.post(
        "/v1/auth/register",
        json={"email": "demo@example.com", "password": "super-secret-123", "display_name": "Demo"},
    )
    if reg.status_code == 409:
        login = client.post(
            "/v1/auth/login",
            json={"email": "demo@example.com", "password": "super-secret-123"},
        )
        token = login.json()["access_token"]
    else:
        token = reg.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_health_endpoint() -> None:
    response = client.get("/v1/system/health")
    assert response.status_code == 200
    assert response.json()["status"] in {"ok", "degraded"}


def test_auth_and_consents_flow() -> None:
    headers = auth_headers()
    consents = client.get("/v1/consents", headers=headers)
    assert consents.status_code == 200
    assert len(consents.json()) == 5

    update = client.put(
        "/v1/consents",
        headers=headers,
        json={"items": [{"code": "analytics_basic", "status": "granted"}]},
    )
    assert update.status_code == 200
    assert any(item["status"] == "granted" for item in update.json() if item["code"] == "analytics_basic")


def test_story_and_studio_flow() -> None:
    headers = auth_headers()
    stories = client.get("/v1/stories", headers=headers)
    assert stories.status_code == 200
    story_id = stories.json()[0]["id"]

    run = client.post(f"/v1/stories/{story_id}/start", headers=headers)
    assert run.status_code == 201
    choice_id = run.json()["available_choices"][0]["id"]

    choice = client.post(
        f"/v1/stories/runs/{run.json()['id']}/choice",
        headers=headers,
        json={"choice_id": choice_id},
    )
    assert choice.status_code == 200

    project = client.post(
        "/v1/studio/projects",
        headers=headers,
        json={"name": "Projet demo", "type": "story"},
    )
    assert project.status_code == 201
    draft = client.put(
        f"/v1/studio/projects/{project.json()['id']}/draft",
        headers=headers,
        json={"payload": {"title": "Hello"}, "version_note": "init"},
    )
    assert draft.status_code == 200
