#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[1/5] verifying required tools"
command -v docker >/dev/null 2>&1 || { echo "docker missing"; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "python3 missing"; exit 1; }

echo "[2/5] preparing env"
if [ ! -f infra/.env ]; then
  cp infra/.env.example infra/.env
fi

echo "[3/5] creating local folders"
mkdir -p .local-data/postgres .local-data/redis .local-data/qdrant .local-data/minio services/api-gateway/data

echo "[4/5] starting minimal stack"
docker compose -f infra/compose/docker-compose.yml --env-file infra/.env up -d --build postgres redis qdrant minio api

echo "[5/5] done"
echo "API:     http://localhost:8000"
echo "Swagger: http://localhost:8000/docs"
echo "Admin:   http://localhost:8000/admin"
