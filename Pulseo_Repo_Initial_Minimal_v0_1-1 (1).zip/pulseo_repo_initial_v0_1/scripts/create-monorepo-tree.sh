#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="${1:-pulseo}"
mkdir -p "$ROOT_DIR"/{apps/{mobile-flutter,web-admin-next},services/{api-gateway,orchestrator-loic,obscura-ingestion,nexus-graph,prisme-policy,deepsense-adaptation,forge-artifacts,trust-layer,review-sandbox},packages/{shared-types,shared-ui,event-schemas,api-client,lint-config},infra/{compose,migrations,monitoring},docs/{architecture,api,product,runbooks},scripts,tests/{contract,integration,e2e}}
echo "[OK] created $ROOT_DIR"
