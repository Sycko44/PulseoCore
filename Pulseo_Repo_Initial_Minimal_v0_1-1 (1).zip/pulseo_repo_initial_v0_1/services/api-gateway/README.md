# API Gateway

Service FastAPI minimal qui porte le noyau executable du MVP.
