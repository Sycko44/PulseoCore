from __future__ import annotations

import json
import sqlite3
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import jwt
from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from .auth import (
    build_access_token,
    build_refresh_token,
    decode_access_token,
    decode_refresh_token,
    make_password_hash,
    now_iso,
    verify_password,
)
from .db import CONSENT_CODES, connect, ensure_default_consents, init_db, log_audit
from .settings import settings


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(title=settings.app_name, version="0.1.0", openapi_url="/openapi.json", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class UserOut(BaseModel):
    id: str
    email: str
    display_name: str


class AuthResponse(BaseModel):
    access_token: str
    refresh_token: str
    user: UserOut


class RegisterRequest(BaseModel):
    email: str
    password: str = Field(min_length=12)
    display_name: str = Field(min_length=2)


class LoginRequest(BaseModel):
    email: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class ConsentUpdate(BaseModel):
    code: str
    status: str


class ConsentUpdateRequest(BaseModel):
    items: list[ConsentUpdate]


class HomeFeedbackIn(BaseModel):
    recommendation_id: UUID
    verdict: str
    comment: str | None = None


class HealthCheckinCreate(BaseModel):
    energy: int = Field(ge=1, le=5)
    mood: int = Field(ge=1, le=5)
    notes: str | None = None


class StudioCreate(BaseModel):
    name: str
    type: str


class StudioDraftSave(BaseModel):
    payload: dict[str, Any]
    version_note: str | None = None


class StoryChoiceIn(BaseModel):
    choice_id: UUID


class ErrorResponse(BaseModel):
    code: str
    message: str
    details: dict[str, Any] | None = None


class AuditEvent(BaseModel):
    id: str
    type: str
    actor_id: str | None = None
    payload: dict[str, Any]
    created_at: str


class AuditPage(BaseModel):
    items: list[AuditEvent]
    next_cursor: str | None = None


def make_error(code: str, message: str, status_code: int, details: dict[str, Any] | None = None) -> None:
    raise HTTPException(status_code=status_code, detail=ErrorResponse(code=code, message=message, details=details).model_dump())


def get_conn() -> sqlite3.Connection:
    return connect()


def get_bearer_token(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        make_error("unauthorized", "Missing bearer token", status.HTTP_401_UNAUTHORIZED)
    return authorization.split(" ", 1)[1]


def get_current_user(token: str = Depends(get_bearer_token)) -> dict[str, Any]:
    try:
        payload = decode_access_token(token)
    except jwt.PyJWTError:
        make_error("unauthorized", "Invalid access token", status.HTTP_401_UNAUTHORIZED)
    user_id = payload.get("sub")
    conn = get_conn()
    try:
        row = conn.execute("SELECT id, email, display_name FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            make_error("unauthorized", "User not found", status.HTTP_401_UNAUTHORIZED)
        return dict(row)
    finally:
        conn.close()


def auth_payload_for_user(row: sqlite3.Row | dict[str, Any]) -> AuthResponse:
    user = dict(row)
    return AuthResponse(
        access_token=build_access_token(user["id"], user["email"]),
        refresh_token=build_refresh_token(user["id"], user["email"]),
        user=UserOut(**user),
    )


def fetch_available_choices(conn: sqlite3.Connection, node_id: str) -> list[dict[str, str]]:
    rows = conn.execute("SELECT id, label FROM story_choices WHERE node_id = ? ORDER BY rowid ASC", (node_id,)).fetchall()
    return [dict(row) for row in rows]


@app.get("/", include_in_schema=False)
def root_endpoint() -> dict[str, str]:
    return {"message": "Pulseo API minimal repo", "docs": "/docs", "admin": "/admin"}


@app.get("/admin", response_class=HTMLResponse, include_in_schema=False)
def admin_page() -> str:
    return (Path(__file__).parent / "static" / "admin.html").read_text(encoding="utf-8")


@app.get("/v1/system/health")
def system_health() -> dict[str, Any]:
    db_status = "ok"
    try:
        conn = get_conn()
        conn.execute("SELECT 1")
        conn.close()
    except Exception:
        db_status = "down"
    return {"status": "ok" if db_status == "ok" else "degraded", "services": {"api": "ok", "db": db_status, "runtime": "ok"}}


@app.post("/v1/auth/register", status_code=201)
def register(payload: RegisterRequest) -> AuthResponse:
    conn = get_conn()
    try:
        existing = conn.execute("SELECT id FROM users WHERE email = ?", (payload.email.lower(),)).fetchone()
        if existing:
            make_error("conflict", "Email already exists", status.HTTP_409_CONFLICT)
        password_hash, salt = make_password_hash(payload.password)
        user_id = str(uuid4())
        conn.execute(
            "INSERT INTO users(id, email, display_name, password_hash, password_salt, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, payload.email.lower(), payload.display_name, password_hash, salt, now_iso()),
        )
        conn.commit()
        ensure_default_consents(conn, user_id)
        log_audit(conn, "auth.registered", user_id, {"email": payload.email.lower()})
        row = conn.execute("SELECT id, email, display_name FROM users WHERE id = ?", (user_id,)).fetchone()
        return auth_payload_for_user(row)
    finally:
        conn.close()


@app.post("/v1/auth/login")
def login(payload: LoginRequest) -> AuthResponse:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT id, email, display_name, password_hash, password_salt FROM users WHERE email = ?",
            (payload.email.lower(),),
        ).fetchone()
        if not row or not verify_password(payload.password, row["password_hash"], row["password_salt"]):
            make_error("unauthorized", "Invalid credentials", status.HTTP_401_UNAUTHORIZED)
        log_audit(conn, "auth.logged_in", row["id"], {"email": row["email"]})
        return auth_payload_for_user(row)
    finally:
        conn.close()


@app.post("/v1/auth/refresh")
def refresh(payload: RefreshRequest) -> AuthResponse:
    try:
        decoded = decode_refresh_token(payload.refresh_token)
    except jwt.PyJWTError:
        make_error("unauthorized", "Invalid refresh token", status.HTTP_401_UNAUTHORIZED)
    conn = get_conn()
    try:
        row = conn.execute("SELECT id, email, display_name FROM users WHERE id = ?", (decoded.get("sub"),)).fetchone()
        if not row:
            make_error("unauthorized", "User not found", status.HTTP_401_UNAUTHORIZED)
        log_audit(conn, "auth.refreshed", row["id"], {})
        return auth_payload_for_user(row)
    finally:
        conn.close()


@app.get("/v1/consents")
def list_consents(current_user: dict[str, Any] = Depends(get_current_user)) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT code, status, updated_at FROM consents WHERE user_id = ? ORDER BY code ASC",
            (current_user["id"],),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


@app.put("/v1/consents")
def update_consents(payload: ConsentUpdateRequest, current_user: dict[str, Any] = Depends(get_current_user)) -> list[dict[str, Any]]:
    invalid = [item.code for item in payload.items if item.code not in CONSENT_CODES]
    if invalid:
        make_error("validation_error", "Unknown consent code", status.HTTP_422_UNPROCESSABLE_ENTITY, {"codes": invalid})
    conn = get_conn()
    try:
        for item in payload.items:
            conn.execute(
                "UPDATE consents SET status = ?, updated_at = ? WHERE user_id = ? AND code = ?",
                (item.status, now_iso(), current_user["id"], item.code),
            )
            log_audit(conn, "consent.updated", current_user["id"], {"code": item.code, "status": item.status})
        rows = conn.execute(
            "SELECT code, status, updated_at FROM consents WHERE user_id = ? ORDER BY code ASC",
            (current_user["id"],),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


@app.get("/v1/home")
def get_home(current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    recommendation_id = str(uuid4())
    return {
        "hero": {
            "title": f"Bonjour {current_user['display_name']}",
            "subtitle": "On te propose une reprise simple et courte.",
            "action_label": "Lancer Focus 3 min",
            "action_type": "ritual.start",
            "explanation": "Suggestion baseline basee sur le MVP, sans moteur implicite avance.",
            "recommendation_id": recommendation_id,
        },
        "shortcuts": [
            {"label": "Check-in sante", "type": "health.checkin"},
            {"label": "Respiration 2 min", "type": "ritual.start"},
            {"label": "Reprendre une histoire", "type": "story.resume"},
        ],
    }


@app.post("/v1/home/feedback", status_code=202)
def home_feedback(payload: HomeFeedbackIn, current_user: dict[str, Any] = Depends(get_current_user)) -> Response:
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO home_feedback(id, user_id, recommendation_id, verdict, comment, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid4()), current_user["id"], str(payload.recommendation_id), payload.verdict, payload.comment, now_iso()),
        )
        log_audit(conn, "home.feedback", current_user["id"], {"recommendation_id": str(payload.recommendation_id), "verdict": payload.verdict})
        return Response(status_code=202)
    finally:
        conn.close()


@app.post("/v1/health/checkins", status_code=201)
def create_checkin(payload: HealthCheckinCreate, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    conn = get_conn()
    try:
        item = {
            "id": str(uuid4()),
            "energy": payload.energy,
            "mood": payload.mood,
            "notes": payload.notes,
            "created_at": now_iso(),
        }
        conn.execute(
            "INSERT INTO health_checkins(id, user_id, energy, mood, notes, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (item["id"], current_user["id"], item["energy"], item["mood"], item["notes"], item["created_at"]),
        )
        log_audit(conn, "health.checkin_created", current_user["id"], {"energy": payload.energy, "mood": payload.mood})
        return item
    finally:
        conn.close()


@app.get("/v1/health/rituals")
def list_rituals(current_user: dict[str, Any] = Depends(get_current_user)) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT id, name, duration_seconds, description FROM rituals ORDER BY name ASC").fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


@app.post("/v1/health/rituals/{ritual_id}/start", status_code=202)
def start_ritual(ritual_id: UUID, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    conn = get_conn()
    try:
        ritual = conn.execute("SELECT id FROM rituals WHERE id = ?", (str(ritual_id),)).fetchone()
        if not ritual:
            make_error("not_found", "Ritual not found", status.HTTP_404_NOT_FOUND)
        item = {"id": str(uuid4()), "ritual_id": str(ritual_id), "status": "started", "started_at": now_iso()}
        conn.execute(
            "INSERT INTO ritual_sessions(id, user_id, ritual_id, status, started_at) VALUES (?, ?, ?, ?, ?)",
            (item["id"], current_user["id"], item["ritual_id"], item["status"], item["started_at"]),
        )
        log_audit(conn, "ritual.started", current_user["id"], {"ritual_id": item["ritual_id"]})
        return item
    finally:
        conn.close()


@app.get("/v1/stories")
def list_stories(current_user: dict[str, Any] = Depends(get_current_user)) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute("SELECT id, title, summary, start_node_id FROM stories ORDER BY title ASC").fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


@app.post("/v1/stories/{story_id}/start", status_code=201)
def start_story(story_id: UUID, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    conn = get_conn()
    try:
        story = conn.execute("SELECT id, start_node_id FROM stories WHERE id = ?", (str(story_id),)).fetchone()
        if not story:
            make_error("not_found", "Story not found", status.HTTP_404_NOT_FOUND)
        run = {
            "id": str(uuid4()),
            "story_id": str(story_id),
            "current_node_id": story["start_node_id"],
            "status": "active",
            "available_choices": fetch_available_choices(conn, story["start_node_id"]),
        }
        ts = now_iso()
        conn.execute(
            "INSERT INTO story_runs(id, user_id, story_id, current_node_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (run["id"], current_user["id"], run["story_id"], run["current_node_id"], run["status"], ts, ts),
        )
        log_audit(conn, "story.started", current_user["id"], {"story_id": run["story_id"]})
        return run
    finally:
        conn.close()


@app.post("/v1/stories/runs/{run_id}/choice")
def make_story_choice(run_id: UUID, payload: StoryChoiceIn, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    conn = get_conn()
    try:
        run = conn.execute(
            "SELECT id, story_id, current_node_id, status FROM story_runs WHERE id = ? AND user_id = ?",
            (str(run_id), current_user["id"]),
        ).fetchone()
        if not run:
            make_error("not_found", "Story run not found", status.HTTP_404_NOT_FOUND)
        choice = conn.execute(
            "SELECT id, next_node_id FROM story_choices WHERE id = ? AND node_id = ?",
            (str(payload.choice_id), run["current_node_id"]),
        ).fetchone()
        if not choice:
            make_error("validation_error", "Invalid choice for current node", status.HTTP_422_UNPROCESSABLE_ENTITY)
        node = conn.execute("SELECT id, is_terminal FROM story_nodes WHERE id = ?", (choice["next_node_id"],)).fetchone()
        status_value = "completed" if node["is_terminal"] else "active"
        conn.execute(
            "UPDATE story_runs SET current_node_id = ?, status = ?, updated_at = ? WHERE id = ?",
            (node["id"], status_value, now_iso(), str(run_id)),
        )
        log_audit(conn, "story.choice_made", current_user["id"], {"run_id": str(run_id), "choice_id": str(payload.choice_id), "next_node_id": node["id"]})
        return {
            "id": str(run_id),
            "story_id": run["story_id"],
            "current_node_id": node["id"],
            "status": status_value,
            "available_choices": [] if status_value == "completed" else fetch_available_choices(conn, node["id"]),
        }
    finally:
        conn.close()


@app.get("/v1/studio/projects")
def list_projects(current_user: dict[str, Any] = Depends(get_current_user)) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT id, name, type, status, updated_at FROM studio_projects WHERE user_id = ? ORDER BY updated_at DESC",
            (current_user["id"],),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


@app.post("/v1/studio/projects", status_code=201)
def create_project(payload: StudioCreate, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    if payload.type not in {"story", "ritual", "deck"}:
        make_error("validation_error", "Invalid project type", status.HTTP_422_UNPROCESSABLE_ENTITY)
    conn = get_conn()
    try:
        item = {"id": str(uuid4()), "name": payload.name, "type": payload.type, "status": "draft", "updated_at": now_iso()}
        conn.execute(
            "INSERT INTO studio_projects(id, user_id, name, type, status, payload_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (item["id"], current_user["id"], item["name"], item["type"], item["status"], json.dumps({}), item["updated_at"]),
        )
        log_audit(conn, "studio.project_created", current_user["id"], {"project_id": item["id"], "type": item["type"]})
        return item
    finally:
        conn.close()


@app.put("/v1/studio/projects/{project_id}/draft")
def save_draft(project_id: UUID, payload: StudioDraftSave, current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    conn = get_conn()
    try:
        project = conn.execute(
            "SELECT id, name, type, status FROM studio_projects WHERE id = ? AND user_id = ?",
            (str(project_id), current_user["id"]),
        ).fetchone()
        if not project:
            make_error("not_found", "Project not found", status.HTTP_404_NOT_FOUND)
        updated_at = now_iso()
        conn.execute(
            "UPDATE studio_projects SET payload_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(payload.payload), updated_at, str(project_id)),
        )
        log_audit(conn, "studio.draft_saved", current_user["id"], {"project_id": str(project_id), "version_note": payload.version_note})
        return {
            "id": project["id"],
            "name": project["name"],
            "type": project["type"],
            "status": project["status"],
            "updated_at": updated_at,
        }
    finally:
        conn.close()


@app.get("/v1/audit/events")
def list_audit_events(cursor: str | None = None, current_user: dict[str, Any] = Depends(get_current_user)) -> AuditPage:
    conn = get_conn()
    try:
        limit = 20
        if cursor:
            rows = conn.execute(
                "SELECT id, type, actor_id, payload_json, created_at FROM audit_events WHERE actor_id = ? AND created_at < ? ORDER BY created_at DESC LIMIT ?",
                (current_user["id"], cursor, limit + 1),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, type, actor_id, payload_json, created_at FROM audit_events WHERE actor_id = ? ORDER BY created_at DESC LIMIT ?",
                (current_user["id"], limit + 1),
            ).fetchall()
        items = [
            AuditEvent(
                id=row["id"],
                type=row["type"],
                actor_id=row["actor_id"],
                payload=json.loads(row["payload_json"]),
                created_at=row["created_at"],
            )
            for row in rows[:limit]
        ]
        next_cursor = rows[limit - 1]["created_at"] if len(rows) > limit else None
        return AuditPage(items=items, next_cursor=next_cursor)
    finally:
        conn.close()


@app.exception_handler(HTTPException)
async def http_exception_handler(_, exc: HTTPException):
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": "http_error", "message": str(exc.detail)}
    return Response(status_code=exc.status_code, media_type="application/json", content=json.dumps(detail))
