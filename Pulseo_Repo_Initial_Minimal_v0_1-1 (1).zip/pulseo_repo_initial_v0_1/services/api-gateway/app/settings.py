from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "Pulseo API")
    app_env: str = os.getenv("APP_ENV", "local")
    jwt_secret: str = os.getenv("JWT_SECRET", "replace_me")
    jwt_refresh_secret: str = os.getenv("JWT_REFRESH_SECRET", "replace_me_too")
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "60"))
    refresh_token_days: int = int(os.getenv("REFRESH_TOKEN_DAYS", "30"))
    database_url: str = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{Path(__file__).resolve().parent.parent / 'data' / 'pulseo.db'}",
    )

    @property
    def sqlite_path(self) -> Path:
        if not self.database_url.startswith("sqlite:///"):
            raise ValueError("Only sqlite is supported in the minimal repo")
        return Path(self.database_url.replace("sqlite:///", ""))


settings = Settings()
