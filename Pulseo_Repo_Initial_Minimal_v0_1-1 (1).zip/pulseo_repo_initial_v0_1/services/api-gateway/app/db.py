from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any
from uuid import uuid4

from .auth import now_iso
from .settings import settings

CONSENT_CODES = [
    "analytics_basic",
    "health_basic",
    "implicit_adaptation",
    "notifications_push",
    "research_anonymized",
]


def _db_path() -> Path:
    path = settings.sqlite_path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = connect()
    try:
        conn.executescript(
            """
            PRAGMA foreign_keys = ON;
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL,
                display_name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                password_salt TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS consents (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                code TEXT NOT NULL,
                status TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(user_id, code),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS home_feedback (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                recommendation_id TEXT NOT NULL,
                verdict TEXT NOT NULL,
                comment TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS health_checkins (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                energy INTEGER NOT NULL,
                mood INTEGER NOT NULL,
                notes TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS rituals (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                duration_seconds INTEGER NOT NULL,
                description TEXT
            );
            CREATE TABLE IF NOT EXISTS ritual_sessions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                ritual_id TEXT NOT NULL,
                status TEXT NOT NULL,
                started_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(ritual_id) REFERENCES rituals(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS stories (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                summary TEXT,
                start_node_id TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS story_nodes (
                id TEXT PRIMARY KEY,
                story_id TEXT NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                is_terminal INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY(story_id) REFERENCES stories(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS story_choices (
                id TEXT PRIMARY KEY,
                node_id TEXT NOT NULL,
                label TEXT NOT NULL,
                next_node_id TEXT NOT NULL,
                FOREIGN KEY(node_id) REFERENCES story_nodes(id) ON DELETE CASCADE,
                FOREIGN KEY(next_node_id) REFERENCES story_nodes(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS story_runs (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                story_id TEXT NOT NULL,
                current_node_id TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(story_id) REFERENCES stories(id) ON DELETE CASCADE,
                FOREIGN KEY(current_node_id) REFERENCES story_nodes(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS studio_projects (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                status TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS audit_events (
                id TEXT PRIMARY KEY,
                type TEXT NOT NULL,
                actor_id TEXT,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        conn.commit()
        seed_reference_data(conn)
    finally:
        conn.close()


def seed_reference_data(conn: sqlite3.Connection) -> None:
    ritual_count = conn.execute("SELECT COUNT(*) AS c FROM rituals").fetchone()["c"]
    if ritual_count == 0:
        rituals = [
            (str(uuid4()), "Respiration 2 min", 120, "Rituel rapide de recentrage"),
            (str(uuid4()), "Reset stress 5 min", 300, "Retour au calme progressif"),
            (str(uuid4()), "Focus 3 min", 180, "Preparation a une tache courte"),
        ]
        conn.executemany(
            "INSERT INTO rituals(id, name, duration_seconds, description) VALUES (?, ?, ?, ?)",
            rituals,
        )

    story_count = conn.execute("SELECT COUNT(*) AS c FROM stories").fetchone()["c"]
    if story_count == 0:
        story_id = str(uuid4())
        start_node = str(uuid4())
        node_focus = str(uuid4())
        node_pause = str(uuid4())
        conn.execute(
            "INSERT INTO stories(id, title, summary, start_node_id) VALUES (?, ?, ?, ?)",
            (story_id, "Premier passage", "Une micro-histoire de recentrage.", start_node),
        )
        nodes = [
            (start_node, story_id, "Debut", "Tu ouvres Pulseo. Quel premier pas choisis-tu ?", 0),
            (node_focus, story_id, "Focus", "Tu choisis une action claire et breve. Fin du demo run.", 1),
            (node_pause, story_id, "Pause", "Tu prends une pause calme. Fin du demo run.", 1),
        ]
        conn.executemany(
            "INSERT INTO story_nodes(id, story_id, title, body, is_terminal) VALUES (?, ?, ?, ?, ?)",
            nodes,
        )
        choices = [
            (str(uuid4()), start_node, "Lancer un focus 3 min", node_focus),
            (str(uuid4()), start_node, "Prendre une pause calme", node_pause),
        ]
        conn.executemany(
            "INSERT INTO story_choices(id, node_id, label, next_node_id) VALUES (?, ?, ?, ?)",
            choices,
        )
    conn.commit()


def log_audit(conn: sqlite3.Connection, event_type: str, actor_id: str | None, payload: dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO audit_events(id, type, actor_id, payload_json, created_at) VALUES (?, ?, ?, ?, ?)",
        (str(uuid4()), event_type, actor_id, json.dumps(payload), now_iso()),
    )
    conn.commit()


def ensure_default_consents(conn: sqlite3.Connection, user_id: str) -> None:
    for code in CONSENT_CODES:
        conn.execute(
            "INSERT OR IGNORE INTO consents(id, user_id, code, status, updated_at) VALUES (?, ?, ?, ?, ?)",
            (str(uuid4()), user_id, code, "denied", now_iso()),
        )
    conn.commit()
