from __future__ import annotations

import hashlib
import hmac
import os
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import uuid4

import jwt

from .settings import settings


def now_iso() -> str:
    return datetime.now(UTC).isoformat()


def make_password_hash(password: str, salt: str | None = None) -> tuple[str, str]:
    real_salt = salt or os.urandom(16).hex()
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), real_salt.encode("utf-8"), 200_000
    )
    return digest.hex(), real_salt


def verify_password(password: str, password_hash: str, salt: str) -> bool:
    computed, _ = make_password_hash(password, salt)
    return hmac.compare_digest(computed, password_hash)


def build_access_token(user_id: str, email: str) -> str:
    payload: dict[str, Any] = {
        "sub": user_id,
        "email": email,
        "type": "access",
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(minutes=settings.access_token_minutes),
        "jti": str(uuid4()),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def build_refresh_token(user_id: str, email: str) -> str:
    payload: dict[str, Any] = {
        "sub": user_id,
        "email": email,
        "type": "refresh",
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(days=settings.refresh_token_days),
        "jti": str(uuid4()),
    }
    return jwt.encode(payload, settings.jwt_refresh_secret, algorithm="HS256")


def decode_access_token(token: str) -> dict[str, Any]:
    return jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])


def decode_refresh_token(token: str) -> dict[str, Any]:
    return jwt.decode(token, settings.jwt_refresh_secret, algorithms=["HS256"])
