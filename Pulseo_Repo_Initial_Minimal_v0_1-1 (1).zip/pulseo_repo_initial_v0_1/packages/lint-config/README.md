# Lint Config

Scaffold reserve pour les conventions de lint et formatage.
