# API Client

Scaffold reserve pour un futur client genere a partir de l'OpenAPI.
