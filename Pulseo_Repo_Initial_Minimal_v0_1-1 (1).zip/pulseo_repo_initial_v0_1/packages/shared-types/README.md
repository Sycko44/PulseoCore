# Shared Types

Source de verite immediate : `docs/api/openapi.yaml` et `packages/event-schemas/`.
