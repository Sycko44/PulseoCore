# Pulseo - Initial Minimal Functional Repository

Ce repo transforme le pack d'execution v1.2 en une base runnable pour une equipe junior.

## Ce qui est fonctionnel tout de suite
- API FastAPI minimale pour le noyau MVP
- Auth basique (register, login, refresh)
- Consentements
- Accueil baseline
- Health checkins et rituels
- Story engine minimal
- Studio projects + sauvegarde de brouillons
- Audit log utilisateur
- Page admin baseline (`/admin`)
- OpenAPI et schemas d'evenements versionnes dans le repo

## Ce qui reste scaffold seulement
- shell mobile Flutter
- backoffice Next.js complet
- microservices separes (Loic, Obscura, Nexus, Prisme, Forge)
- edge runtime, spatial shell et simulation avancee

## Demarrage rapide
```bash
cp infra/.env.example infra/.env
bash scripts/bootstrap.sh
```

Ensuite :
- API : `http://localhost:8000`
- Swagger : `http://localhost:8000/docs`
- Admin baseline : `http://localhost:8000/admin`

## Decision d'architecture
Pour cette version initiale, le repo privilegie un **noyau monolithique modulaire** dans `services/api-gateway` afin de livrer vite un systeme demonstrable. Les futurs microservices restent representes dans la structure et dans la documentation, mais ne sont pas encore decoupes en processus independants.
