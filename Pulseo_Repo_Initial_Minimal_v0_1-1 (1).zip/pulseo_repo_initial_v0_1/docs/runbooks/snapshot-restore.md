# Runbook - Snapshot / Restore

## Creation snapshot manuel
- appeler route snapshot
- verifier hash et metadata
- verifier stockage distant si configure

## Restore
1. choisir snapshot ou chaine de deltas
2. mettre systeme en maintenance courte si necessaire
3. lancer restore
4. verifier integrite manifest
5. verifier health

## Post-restore
- smoke test auth
- smoke test accueil
- smoke test rituel
- smoke test story
