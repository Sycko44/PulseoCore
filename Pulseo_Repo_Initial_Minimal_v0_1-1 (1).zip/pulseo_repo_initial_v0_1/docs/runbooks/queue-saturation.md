# Runbook - Saturation des queues

## Symptomes
- jobs retardes
- home non mis a jour
- workers a 100%

## Verification
1. taille des queues Redis
2. jobs en retry
3. dead letters
4. temps moyen d'execution

## Actions
- suspendre jobs non critiques
- augmenter workers temporaires
- purger jobs invalides
- verifier job empoisonne

## Prevention
- quotas par queue
- priorites P0/P1 distinctes
- alerte sur taille queue
