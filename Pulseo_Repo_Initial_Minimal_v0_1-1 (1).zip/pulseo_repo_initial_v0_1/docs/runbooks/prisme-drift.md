# Runbook - Derive Prisme

## Symptomes
- recommandations absurdes
- baisse forte d'acceptation
- hausse des regrets

## Actions immediates
1. desactiver politique fautive via feature flag
2. revenir a la version precedente
3. figer promotion automatique
4. exporter les exemples fautifs

## Verification
- comparer policy version
- verifier feedback recents
- lancer canary offline

## Sortie d'incident
- policy stable restauree
- rapport de cause racine documente
