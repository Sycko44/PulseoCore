# Runbook - Auth indisponible

## Symptomes
- login KO
- refresh token KO
- pic de 401/500

## Verification rapide
1. verifier `GET /health`
2. verifier base Postgres
3. verifier redis/session store
4. verifier provider JWT / cles

## Actions
- activer mode maintenance auth si necessaire
- redemarrer service auth
- verifier migrations non appliquees
- invalider caches JWT si corruption suspectee

## Escalade
- lead backend
- ops

## Validation retour
- login web OK
- login mobile OK
- refresh token OK
- logs erreurs revenus a la normale
