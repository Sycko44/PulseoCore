# Definition of Done

## Commune a tous les tickets
- code merge sur branche principale
- tests unitaires ou de contrat ecrits
- logs minimaux ajoutes
- docs README mises a jour
- feature flag documente si necessaire
- capture d'ecran ou preuve fonctionnelle jointe
- aucune alerte critique de securite introduite

## Pour une route API
- declaree dans `api/openapi.yaml`
- schema request/response stable
- gestion des erreurs 400/401/403/404/409/500
- test de contrat present
- auth et permissions verifiees

## Pour une vue front
- etat vide
- etat loading
- etat erreur
- etat offline si necessaire
- analytics minimum
- accessibilite clavier / lecteur logique

## Pour un job async
- idempotence documentee
- retry policy documentee
- dead letter ou equivalent documente
- logs d'echec exploitables

## Pour un module sensible
- audit log present
- consentement verifie
- rollback ou kill switch documente
