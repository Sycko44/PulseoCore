# Monorepo cible

```text
pulseo/
  apps/
    mobile-flutter/
    web-admin-next/
  services/
    api-gateway/
    orchestrator-loic/
    obscura-ingestion/
    nexus-graph/
    prisme-policy/
    deepsense-adaptation/
    forge-artifacts/
    trust-layer/
    review-sandbox/
  packages/
    shared-types/
    shared-ui/
    event-schemas/
    api-client/
    lint-config/
  infra/
    docker/
    compose/
    migrations/
    monitoring/
  docs/
    architecture/
    api/
    runbooks/
    product/
  scripts/
  tests/
    contract/
    integration/
    e2e/
```

## Regles
- Chaque service a son README, son Dockerfile, ses variables d'environnement et ses tests de sante.
- `packages/shared-types` est la source de verite des schemas partages.
- Les migrations vivent dans `infra/migrations`.
- Les schemas JSON d'evenements et l'OpenAPI doivent etre versionnes ensemble.
- Aucun secret dans le repo.
