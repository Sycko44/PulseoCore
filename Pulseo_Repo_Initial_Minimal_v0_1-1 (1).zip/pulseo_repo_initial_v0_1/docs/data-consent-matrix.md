# Matrice Donnees / Consentements

| Donnee | Source | Finalite | Consentement | Sensibilite | Retention | Exportable | Effacable | Moteurs |
|---|---|---|---|---|---|---|---|---|
| email | utilisateur | auth, communication de service | implicite contractuel | moyen | compte actif + 30j | oui | oui | auth |
| mot de passe hash | systeme | auth | implicite contractuel | eleve | compte actif | non | oui | auth |
| evenement navigation | app mobile/web | analytics produit, accueil simple | analytics produit | moyen | 12 mois | oui | oui | obscura, prisme |
| consentements | utilisateur | conformite, audit | explicite | eleve | vie du compte + 5 ans audit | oui | partiel selon loi | trust |
| check-in sante | utilisateur | module sante, recommandations non medicales | sante explicite | eleve | 12 mois par defaut | oui | oui | sante, prisme |
| evenement rituel | app | reprise, progression, analytics | sante explicite | eleve | 12 mois | oui | oui | sante, analytics |
| choix narratif | utilisateur | progression story | service + contenu | moyen | 24 mois | oui | oui | play, nexus |
| brouillon studio | utilisateur | creation | service | moyen | compte actif | oui | oui | studio, forge |
| device id | app | securite session, push | device explicite | moyen | 12 mois | oui | oui | auth, notifications |
| signals implicites legers | app locale | adaptation locale si activee | implicite dedie explicite | eleve | 90 jours par defaut | oui | oui | deepsense |

## Regles
- Aucun signal implicite sans consentement dedie.
- Les donnees sante et implicites ne sont jamais activees par defaut.
- Toute recommandation sensible doit pouvoir etre reliee a une categorie de donnees et a un consentement valide.
