# Baseline UX Reference

## Principes
- calme
- explicable
- peu de texte en surface
- une action principale lisible en moins de 3 secondes
- aucun jargon interne visible

## Ecrans MVP obligatoires
### 1. Accueil
- hero principal
- une action suggeree
- reprise en cours
- acces SOS
- feedback simple: accepter / plus tard

### 2. Sante
- check-in rapide
- rituel principal
- historique tres court
- indicateur simple d'energie ou progression

### 3. Jouer
- reprendre histoire
- demarrer histoire simple
- affichage d'un choix actif

### 4. Creer
- liste des projets
- ouvrir brouillon
- creer un projet simple

### 5. Profil / Reglages
- consentements
- deconnexion
- appareil
- export / suppression demande

## Etats obligatoires par ecran
- vide
- chargement
- erreur recuperable
- hors ligne degrade

## Composants obligatoires
- carte recommandation
- feuille de consentement
- bandeau d'explication
- CTA primaire
- journal d'erreur lisible
