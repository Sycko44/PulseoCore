# Checklist Go / No-Go

## Go si tout est vrai
- environnement local monte en moins de 30 min
- auth et consentements fonctionnent
- OpenAPI compile sans erreur
- routes P0 testees
- Accueil, Sante, Jouer, Creer, Profil demonstrables
- audit log visible en backoffice
- aucun blocker critique securite
- runbooks incidents existent

## No-Go si un point est faux
- pas de trace des consentements
- pas de strategie rollback
- pas de healthcheck stable
- pas de tests de contrat API
- pas de definition de Done partagee
- l'equipe ne sait pas reproduire la stack localement
