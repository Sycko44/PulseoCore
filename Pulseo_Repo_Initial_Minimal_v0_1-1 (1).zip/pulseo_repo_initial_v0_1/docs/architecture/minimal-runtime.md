# Minimal Runtime Decision

La version initiale fonctionnelle execute le noyau MVP dans `services/api-gateway` sous forme de monolithe modulaire.

## Inclus
- auth
- consentements
- accueil baseline
- sante baseline
- stories basiques
- studio minimal
- audit log
- page admin baseline

## Reporte
- Loic en worker separe
- Obscura, Nexus, Prisme, Forge en services independants
- event bus externe
- edge runtime
- shell spatial/audio
