# MVP Contract - Pulseo v1

## Objectif du MVP
Livrer un noyau demonstrable, securise, documente et mesurable. Le MVP doit prouver la chaine complete suivante :
- authentifier un utilisateur
- recueillir les consentements minimums
- charger un accueil simple et predictif baseline
- lancer un rituel sante simple
- executer une histoire courte a choix
- creer puis sauvegarder un brouillon Studio
- exposer ces actions dans un backoffice minimal
- tracer les actions dans un audit log

## Inclus dans le MVP
### Noyau plateforme
- runtime local avec healthcheck
- manifest de configuration
- gestion des erreurs minimum
- audit log minimum
- snapshots manuels minimum

### Identite et confiance
- inscription / connexion
- reset mot de passe
- consentements granulaires initiaux
- export utilisateur demande simple
- suppression utilisateur mode file d'attente

### Experience utilisateur
- Accueil baseline
- Module Sante minimal
- Story Engine minimal
- Studio brouillon minimal
- Profil / Reglages / Consentements

### Administration
- backoffice minimal lecture seule + quelques actions support
- visualisation des utilisateurs
- visualisation des consentements
- visualisation des incidents applicatifs

## Hors MVP
- marketplace complete
- licences B2B completes
- social public avance
- interface spatiale complete
- biometrie avancee
- simulation massive lot 32 complete
- apprentissage par renforcement autonome en production
- haptique / audio spatial complexes
- phygital complet

## Maquette seulement, pas de developpement MVP
- lot 31 complet
- lot 32 complet
- creator economy complete
- SDK partenaire
- analytics avances de monetisation

## Conditions de sortie MVP
- toutes les routes P0 implementees
- tous les consentements P0 traces
- environnement local reproductible en moins de 30 minutes
- 0 blocage critique de securite ouvert
- tous les parcours MVP passes en test manuel E2E
